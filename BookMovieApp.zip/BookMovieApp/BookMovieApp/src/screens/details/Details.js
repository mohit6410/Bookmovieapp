import React, { useState, useEffect } from 'react';
import {
  GridList,
  GridListTile,
  GridListTileBar,
  Typography,
  Button,
  IconButton,
  StarBorderIcon,
} from '@mui/material';
import YouTube from 'react-youtube';


const DetailsPage = () => {
  const [movieData, setMovieData] = useState({});

  useEffect(() => {
  }, []);

  const handleRatingClick = (rating) => {
  };

  return (
    <div>
      <header>
        {}
        <IconButton className="back-to-home-button">
          <Typography variant="body2">
            <>&lt;</> Back to Home
          </Typography>
        </IconButton>
      </header>

      <div className="details-page-content">
        <div className="left-part">
          <img src={movieData.poster_url} alt={movieData.title} />
        </div>

        <div className="middle-part">
          <Typography variant="h2">{movieData.title}</Typography>
          {}
          <Typography variant="body1" gutterBottom>
            Plot
          </Typography>
          <Typography variant="body2" component="p">
            {movieData.story_line}
            <br />
            <a href={movieData.wiki_url}>Read more on Wikipedia</a>
          </Typography>
          <Typography variant="body1" gutterBottom>
            Trailer
          </Typography>
          <YouTube videoId={movieData.trailer_url} />
        </div>

        <div className="right-part">
          <Typography variant="body1" gutterBottom>
            Rate this movie:
          </Typography>
          {[...Array(5)].map((_, index) => (
            <StarBorderIcon
              key={index}
              onClick={() => handleRatingClick(index + 1)}
            />
          ))}
          {}
        </div>
      </div>
    </div>
  );
};

export default DetailsPage;
