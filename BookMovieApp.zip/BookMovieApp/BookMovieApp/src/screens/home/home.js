import React, { useState } from 'react';
import {
  GridList,
  GridListTile,
  GridListTileBar,
  Card,
  CardContent,
  Typography,
  FormControl,
  InputLabel,
  Input,
  Select,
  MenuItem,
  Checkbox,
  Button,
  TextField,
} from '@mui/material';


const HomePage = () => {
  const [upcomingMovies, setUpcomingMovies] = useState([]);
  const [releasedMovies, setReleasedMovies] = useState([]);
  const [filters, setFilters] = useState({
    movieName: '',
    genres: [],
    artists: [],
    releaseDateStart: '',
    releaseDateEnd: '',
  });


  return (
    <div>
      <Header /> {}

      <div className="upcoming-movies-heading">Upcoming Movies</div>
      <GridList cols={6} cellHeight={250}>
        {}
      </GridList>

      <div className="main-content">
        <div className="movies-grid">
          <GridList cols={4} cellHeight={350}>
            {}
          </GridList>
        </div>
        <div className="filters-card">
          <Card>
            <CardContent>
              <Typography variant="h6" color="primary">FIND MOVIES BY:</Typography>
              <FormControl>
                <InputLabel>Movie Name</InputLabel>
                <Input value={filters.movieName} onChange={handleMovieNameChange} />
              </FormControl>
              {}
              <Button variant="contained" color="primary">APPLY</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
