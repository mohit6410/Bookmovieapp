import React, { useState } from 'react';
import './Header.css';
import Button from '@mui/material/Button';
import Modal from 'react-modal';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import { useHistory } from 'react-router-dom'; 


const Header = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [accessToken, setAccessToken] = useState(null); 
  const history = useHistory();


  return (
    <header className="header">
      <img src="/assets/logo.svg" alt="Logo" className="logo" />
      <Button variant="contained" color="primary" onClick={() => handleBookShow()}>
        Book Show
      </Button>
      {accessToken ? (
        <Button variant="contained" color="default" onClick={handleLogout}>
          Logout
        </Button>
      ) : (
        <Button variant="contained" color="default" onClick={() => setIsModalOpen(true)}>
          Login
        </Button>
      )}
      {isModalOpen && (
        <Modal isOpen={isModalOpen} onRequestClose={() => setIsModalOpen(false)}>
          {}
        </Modal>
      )}
    </header>
  );
};

export default Header;
